# TODO

* Melhorar zoom dos screenshots
* Wrench só funciona com login do Github
* Handle when property finishedAt is null
* Figure out how to break Updater up
* Publish extension on Chrome Web Store
* Divulgar no facebook: globo.com, rio.js e Javascript Brasil
* Implement grunt tasks
* Create javascript specs
* Deploy project on Github
* Deploy project on TravisCI
* class ModelLocalStorage < Model < Source
* Pause option: removes badge and stops updater


## Version 2
* "Enable notifications" options
* Check chrome.storage.sync
* Login no Github
* Múltiplos projetos


## Version 3
* MyCI: suporte para outros CI (Jenkins, TeamCity, ...)
* Multiplas fontes de projetos
