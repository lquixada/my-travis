# MyTravis

Monitor your projects builds from TravisCI within Chrome.

## Development

### Installing Tools

```bash
$ npm install
```

### Tests

```bash
$ npm test
```
