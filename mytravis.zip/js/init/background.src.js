document.addEventListener('DOMContentLoaded', function () {
	Badge.update(Projs.get());

	Updater.start();
});
